package com.example.coronacrusaders.ui.home;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.coronacrusaders.R;

import java.util.ArrayList;
import java.util.Locale;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    Button submitBtn,submitBtn1;
    ImageView aiLogo;
    SpeechRecognizer recognizer;
    TextToSpeech tts;

    public static final Integer RecordAudioRequestCode = 1;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
 /*       final TextView textView = root.findViewById(R.id.text_home);
        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
*/
        submitBtn=root.findViewById(R.id.submitBtn);
        submitBtn1=root.findViewById(R.id.submitBtn1);
        aiLogo=root.findViewById(R.id.aiLogo);

        submitBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitBtn.setEnabled(true);
                submitBtn1.setEnabled(false);
                Toast.makeText(getActivity().getApplicationContext(), "Please wait! Sanitizer Dispenser is turnng OFF.", Toast.LENGTH_SHORT).show();
            }
        });
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitBtn1.setEnabled(true);
                submitBtn.setEnabled(false);
                Toast.makeText(getActivity().getApplicationContext(), "Please wait! Sanitizer Dispenser is turning ON.", Toast.LENGTH_SHORT).show();
            }
        });

        if(ContextCompat.checkSelfPermission(getActivity().getApplicationContext(), Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED){
            checkPermission();
        }

        tts=new TextToSpeech(getActivity().getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if(i != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.UK);
                }
            }
        });

        aiLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(getActivity().getApplicationContext());

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, "this package");
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
                recognizer.startListening(intent);

                recognizer.setRecognitionListener(new RecognitionListener() {
                    @Override
                    public void onReadyForSpeech(Bundle params) {

                    }

                    @Override
                    public void onBeginningOfSpeech() {

                    }

                    @Override
                    public void onRmsChanged(float rmsdB) {

                    }

                    @Override
                    public void onBufferReceived(byte[] buffer) {

                    }

                    @Override
                    public void onEndOfSpeech() {

                    }

                    @Override
                    public void onError(int error) {

                    }

                    @Override
                    public void onResults(Bundle results) {
                        ArrayList<String> res= results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        Log.v("pratik","speech=="+res.get(0));

                        if(res.get(0).contains("on") ){
                            tts.speak("Ok, Turning on the Sanitizer Dispenser",TextToSpeech.QUEUE_FLUSH,null);
                            submitBtn1.setEnabled(true);
                            submitBtn.setEnabled(false);
                        }
                        else if (res.get(0).contains("off")) {
                            tts.speak("Ok, Turning off the Sanitizer Dispenser", TextToSpeech.QUEUE_FLUSH, null);
                            submitBtn1.setEnabled(false);
                            submitBtn.setEnabled(true);
                        }
                    }

                    @Override
                    public void onPartialResults(Bundle partialResults) {

                    }

                    @Override
                    public void onEvent(int eventType, Bundle params) {

                    }
                });

              }
        });



        return root;
    }

    private void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.RECORD_AUDIO},RecordAudioRequestCode);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RecordAudioRequestCode && grantResults.length > 0 ){
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
                Toast.makeText(getActivity().getApplicationContext(),"Permission Granted",Toast.LENGTH_SHORT).show();
        }
    }
}
